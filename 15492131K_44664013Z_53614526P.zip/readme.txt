Iago Moreda Expósito(15492131K), Selene Carnero Cid(44664013Z), Pedro Jalda Fonseca(53614526P)

El proyecto esta levantado con docker, el cual en el archivo Makefile tienes comandos para desplegar los contenedores de manera mas comoda(utiliza "make deploy" para levantar el proyecto en desarrollo, "make consumer" para lanzar el servicio que consume los mensajes y de esta forma que funcionen los checks y make client-dev para ejecutar el servidor de vite y poder visualizar el frontend), vas a necesitar hacer un "composer install" dentro del contenedor de php.

Para los ususarios, tienes un formulario para poder registarte y crear tus propios usarios para utilizar en el login.

Ademas tienes el proyecto en este repositorio de git https://github.com/MOREXPO/IAmOnV2